# HTML5-Flappy-Bird
A Simple Flappy Bird Game clone made in HTML5 using Phaser Game Engine

## How to use
Download the project zip file or clone it and open the index.html file.
